Quick start
-----------

 Use it like this:

    python -m mymark

details:
        <em> begin and end with *

        <strong> begin and end with **

        email put in < >

        simple link directly put in < >

        complicate link like this: [text](link)

        picture use link like this: ![picturename](picturelink)

        inline code put in ``

        headings begin with #, numbers of # means the level of heading
        the first heading is the title, to be different, appended with a <hr>

        blockquotes begin with >

        lists begin with - mean unordered, with + mean ordered

        *** mean a <hr>
        
        blockcode put between ``` and ```
